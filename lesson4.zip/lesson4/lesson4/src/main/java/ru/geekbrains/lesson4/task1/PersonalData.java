package ru.geekbrains.lesson4.task1;

public interface PersonalData {

    String getInn();

}
