package ru.geekbrains.lesson4;

public class Employee {

    private String name;

    public String getName() {
        return name;
    }

    public Employee(String name) {
        this.name = name;
    }
}
