package ru.geekbrains.lesson4.homework;

public class Program {

    /**
     Домашняя работа, задача:
     ========================

     a. Даны классы Fruit, Apple extends Fruit, Orange extends Fruit;
     b. Класс Box, в который можно складывать фрукты. Коробки условно сортируются по типу фрукта,
     поэтому в одну коробку нельзя сложить и яблоки, и апельсины;
     c. Для хранения фруктов внутри коробки можно использовать ArrayList;
     d. Сделать метод getWeight(), который высчитывает вес коробки, зная вес одного фрукта и их количество:
     вес яблока – 1.0f, апельсина – 1.5f (единицы измерения не важны);
     e. Внутри класса Box сделать метод compare(), который позволяет сравнить текущую коробку с той, которую
     подадут в compare() в качестве параметра. true – если их массы равны, false в противоположном случае.
     Можно сравнивать коробки с яблоками и апельсинами;
     f. Написать метод, который позволяет пересыпать фрукты из текущей коробки в другую.
     Помним про сортировку фруктов: нельзя яблоки высыпать в коробку с апельсинами.
     Соответственно, в текущей коробке фруктов не остается, а в другую перекидываются объекты, которые были в первой;
     g. Не забываем про метод добавления фрукта в коробку.
     */
    public static void main(String[] args) {
        Box<Orange> orangeBox = new Box<>(); // принесли пустую коробку для апельсинов
        orangeBox.add(new Orange());  //добавили 1-й апельсин
        orangeBox.add(new Orange());  //добавили 2-й апельсин

        //orangeBox.add(new Apple());  //яблоко в коробку с апельсинами не добавляется, т.к. при создании указали Box<Orange>

        System.out.println("Вес коробки с апельсинами: " + orangeBox.getWeight());
        System.out.println();

        Box<Apple> appleBox = new Box<>(); // принесли пустую коробку для яблок
        appleBox.add(new Apple());  // добавили 1-e яблоко
        appleBox.add(new Apple());  // добавили 2-e яблоко
        appleBox.add(new Apple());  // добавили 3-e яблоко
        System.out.println(("Вес коробки с яблоками: " + appleBox.getWeight()));
        System.out.println();
        System.out.println("Сравнение коробки с яблоками с коробкой с апельсинами по весу:");
        System.out.println(appleBox.compare(orangeBox));

        Box<Apple> appleBox1 = new Box<>(); // создали еще одну коробку для яблок
        appleBox1.add(new Apple()); // добавили в нее 1 яблоко
        System.out.println(("Вес новой коробки с яблоками: " + appleBox1.getWeight()));

        System.out.println("Сравнение 2 коробок с яблоками по весу:");
        System.out.println(appleBox.compare(appleBox1)); // выводим результат сравнения двух коробок с яблоками
        System.out.println();

appleBox.pourTo(appleBox1); // перекладываем яблоки из коробки в новую коробку
        System.out.println("Вес второй коробки с яблоками после перекладывания из первой: " + appleBox1.getWeight());
        System.out.println("Вес первой коробки с яблоками после перекладывания во вторую: " + appleBox.getWeight());
    }
}
