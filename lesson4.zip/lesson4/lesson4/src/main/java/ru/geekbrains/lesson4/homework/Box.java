package ru.geekbrains.lesson4.homework;

import java.util.ArrayList;

public class Box <T extends Fruit> {

    private ArrayList<T> fruits;
    private float boxWeight;

    public Box() {
        this.fruits = new ArrayList<>();
    }

    public void add(T fruit) {
        fruits.add(fruit);
        boxWeight += fruit.GetFruitWeight();
    }


    public float getWeight() {
        return boxWeight;
    }

    public boolean compare(Box<?> box) {
        return Float.compare(this.getWeight(), box.getWeight()) == 0;
    }


    public void pourTo(Box<T> box) {
        for (T fruit : fruits) {
            box.add(fruit);
        }
        fruits.clear();
        boxWeight = 0;

    }


}





